import { Link } from "react-router-dom";


function Accommodation() {
    return (
        <div>
        <h1>hello world</h1>
            <Link to="/accommodation/form">Form</Link>
        </div>
    )
}

export default Accommodation;