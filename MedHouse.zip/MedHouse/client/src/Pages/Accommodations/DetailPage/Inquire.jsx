function Inquire() {
    return <h1>Hello World</h1>
}

export default Inquire;