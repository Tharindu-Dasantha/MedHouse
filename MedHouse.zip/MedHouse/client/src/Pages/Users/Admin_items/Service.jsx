
function service(){
    return<h1>Service</h1>
}
export default service;