
function Stuff(){
    return<h1>Stuff</h1>
}
export default Stuff;