const Map = () => {
  return <div className="sections map">
    <img src="/Image/map.jpg" alt="" />
    <h3>
      Embark on Your Medical Journey with Us Today!
    </h3>
  </div>;
};

export default Map;
